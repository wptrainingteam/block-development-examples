import { registerSlotFillWithPluginDocumentSettingPanel } from './slotfill-PluginDocumentSettingPanel-2fb190';
import { registerSlotFillWithPluginSidebar } from './slotfill-PluginSidebar-2fb190';

registerSlotFillWithPluginDocumentSettingPanel();
registerSlotFillWithPluginSidebar();
