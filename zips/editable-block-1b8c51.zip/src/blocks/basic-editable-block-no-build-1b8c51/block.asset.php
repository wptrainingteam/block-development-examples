<?php return [
    "dependencies" => ["react", "wp-block-editor", "wp-blocks"],
    "version" => "jns4hjf256k63try7oq4",
];
